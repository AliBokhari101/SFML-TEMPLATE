# sfml-template-vs
This is a template that is meant to make the Sfml Setup really easy. These are the steps you will follow:
1. Download this project as .zip or fork it if you are a pro.
2. Unzip it. (Obviously)
3. Double-click on .sln file. It should open in Visual Studio.
5. Then just run it, and it should run with a green circle in the window.
6. 🎉Cheers! you have just set up your Sfml project.

## What if it doesn't work?
I have tested it thoroughly. But if it doesn't work you should create an issue on Git Hub and give your device specs and visual studio version. I will provide a solution.
